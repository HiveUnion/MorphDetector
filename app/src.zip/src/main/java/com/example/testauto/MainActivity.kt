package com.example.testauto

import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.InputDevice
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : ComponentActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: InfiniteScrollAdapter
    private var dataList = mutableListOf<String>()
    private var isLoading = false
    private val visibleThreshold = 5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // 正确设置 activity_main 布局文件
        setContentView(R.layout.activity_main)

        // 初始化 RecyclerView
        setupRecyclerView()

        // 加载初始数据
        loadData()

        // 检测 AutoJs 操作
        detectAutoJsOperation()
    }

    private fun testAdbProcess(){

    }

    private fun setupRecyclerView() {
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = InfiniteScrollAdapter(dataList)
        recyclerView.adapter = adapter

        // 设置滚动监听器，实现无限加载功能
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val linearLayoutManager = recyclerView.layoutManager as LinearLayoutManager
                val totalItemCount = linearLayoutManager.itemCount
                val lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition()

                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    // 加载更多数据
                    loadData()
                    isLoading = true
                }
            }
        })
    }

    private fun loadData() {
        // 模拟数据加载延迟
        recyclerView.postDelayed({
            val start = dataList.size
            val end = start + 20
            for (i in start until end) {
                dataList.add("Item $i")
            }
            adapter.notifyDataSetChanged()
            isLoading = false
        }, 1500)
    }

    private fun detectAutoJsOperation() {
        // 需要用户在系统设置中授予 PACKAGE_USAGE_STATS 权限
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val currentTime = System.currentTimeMillis()

        // 获取最近1小时的应用使用情况
        val usageStatsList: List<UsageStats> = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            currentTime - 1000 * 3600,
            currentTime
        )

        // 输出每个应用的包名和最后使用时间
        for (usageStats in usageStatsList) {
            Log.d("UsageStats", "Package: ${usageStats.packageName} LastTimeUsed: ${usageStats.lastTimeUsed}")
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {

        // 确保 ev 不为空
        if (ev != null) {
            Log.d("dispatchTouchEvent Touch Detection", "Event source is " + ev.source)

            Log.d("dispatchTouchEvent ToolType", "ev != null" )

            // 判断事件源是否来自触摸屏
            if ((ev.source and InputDevice.SOURCE_TOUCHSCREEN) != InputDevice.SOURCE_TOUCHSCREEN) {
                Log.d("dispatchTouchEvent Touch Detection", "Event is not from a touchscreen")
                // 可能是脚本模拟触摸事件
            }

            // 获取第一个触摸点的工具类型
            val toolType = ev.getToolType(0)
            Log.d("dispatchTouchEvent ToolType", "First ToolType source is " + toolType)
            // 根据工具类型进行判断
            when (toolType) {
                MotionEvent.TOOL_TYPE_FINGER -> Log.d("dispatchTouchEvent ToolType", "Tool type is finger")
                MotionEvent.TOOL_TYPE_STYLUS -> Log.d("dispatchTouchEvent ToolType", "Tool type is stylus")
                MotionEvent.TOOL_TYPE_MOUSE -> Log.d("dispatchTouchEvent ToolType", "Tool type is mouse")
                MotionEvent.TOOL_TYPE_ERASER -> Log.d("dispatchTouchEvent ToolType", "Tool type is eraser")
                MotionEvent.TOOL_TYPE_UNKNOWN -> Log.d("dispatchTouchEvent ToolType", "Tool type is unknwn")
                else -> Log.d("dispatchTouchEvent ToolType", "Unknown tool type: $toolType")
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // 确保 ev 不为空
        Log.d("onTouchEvent Touch Detection", "Event source is " + event.source)

        Log.d("onTouchEvent ToolType", "ev != null" )

        // 判断事件源是否来自触摸屏
        if ((event.source and InputDevice.SOURCE_TOUCHSCREEN) != InputDevice.SOURCE_TOUCHSCREEN) {
            Log.d("onTouchEvent Touch Detection", "Event is not from a touchscreen")
            // 可能是脚本模拟触摸事件
        }

        // 获取第一个触摸点的工具类型
        val toolType = event.getToolType(0)
        Log.d("onTouchEvent ToolType", "First ToolType source is " + toolType)
        // 根据工具类型进行判断
        when (toolType) {
            MotionEvent.TOOL_TYPE_FINGER -> Log.d("onTouchEvent ToolType", "Tool type is finger")
            MotionEvent.TOOL_TYPE_STYLUS -> Log.d("onTouchEvent ToolType", "Tool type is stylus")
            MotionEvent.TOOL_TYPE_MOUSE -> Log.d("onTouchEvent ToolType", "Tool type is mouse")
            MotionEvent.TOOL_TYPE_ERASER -> Log.d("onTouchEvent ToolType", "Tool type is eraser")
            MotionEvent.TOOL_TYPE_UNKNOWN -> Log.d("onTouchEvent ToolType", "Tool type is unknwn")

            else -> Log.d("onTouchEvent ToolType", "Unknown tool type: $toolType")
        }
        return super.onTouchEvent(event)
    }
}
